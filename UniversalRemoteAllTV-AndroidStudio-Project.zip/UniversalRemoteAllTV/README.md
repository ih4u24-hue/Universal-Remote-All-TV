# Universal Remote – All TV (Starter Android Project)

This is an Android Studio starter project for an IR-based universal remote.

## Important limitations
- The app uses Android's `ConsumerIrManager` API. Android must expose a compatible IR emitter.
- The app includes generic NEC-format *test signals only*. They are not verified Walton codes and will not operate every TV.
- Selecting a brand is currently a label only; it does not imply that a verified code set exists for that brand.
- Real universal support requires verified protocol/address/command data for each TV model or remote family.
- Some phones have IR hardware but do not expose it through the standard Android API. In that case this app cannot transmit through the built-in API.

## Build
1. Install Android Studio.
2. Choose **Open** and select this project folder.
3. Let Gradle sync.
4. Connect an Android phone, then press Run; or use Build > Build APK(s).

The project targets Android SDK 35 and uses Kotlin with the Android framework only.
