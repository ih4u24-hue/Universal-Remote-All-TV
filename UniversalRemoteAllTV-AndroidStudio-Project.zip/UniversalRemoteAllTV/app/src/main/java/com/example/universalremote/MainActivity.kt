package com.example.universalremote

import android.app.Activity
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.content.Context

class MainActivity : Activity() {
    private lateinit var ir: ConsumerIrManager
    private lateinit var status: TextView
    private lateinit var brand: Spinner
    private lateinit var profile: Spinner
    private lateinit var sendButtons: LinearLayout

    // These are example NEC-format test codes, NOT verified codes for every TV.
    // A matching manufacturer/model code set must be added for reliable control.
    private data class IrProfile(val label: String, val address: Int, val protocol: String = "NEC")
    private val profiles = listOf(
        IrProfile("Generic NEC test profile A", 0x00),
        IrProfile("Generic NEC test profile B", 0x01),
        IrProfile("Generic NEC test profile C", 0x04)
    )

    // NEC command bytes commonly used in test remotes; model-specific mapping varies.
    private val commands = linkedMapOf(
        "Power" to 0x12, "Volume +" to 0x10, "Volume −" to 0x11,
        "Mute" to 0x0D, "Channel +" to 0x20, "Channel −" to 0x21,
        "Up" to 0x18, "Down" to 0x19, "Left" to 0x1B, "Right" to 0x1A,
        "OK" to 0x1C, "Menu" to 0x1F, "Back" to 0x0B, "Source" to 0x0C
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as ConsumerIrManager

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        fun label(text: String, size: Float = 16f): TextView = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(28, 39, 56))
            setPadding(4, 12, 4, 8)
        }
        page.addView(label("Universal Remote", 26f))
        page.addView(label("All TV • Infrared Remote", 14f))
        page.addView(label("TV Brand"))
        brand = Spinner(this)
        val brands = listOf("Walton", "Samsung", "LG", "Sony", "TCL", "Hisense",
            "Xiaomi", "Panasonic", "Philips", "Toshiba", "Sharp", "Haier", "Other")
        brand.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, brands)
        page.addView(brand)

        page.addView(label("IR test profile"))
        profile = Spinner(this)
        profile.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            profiles.map { it.label })
        page.addView(profile)

        status = label("", 14f)
        page.addView(status)
        updateStatus()

        page.addView(label("Remote controls", 20f))
        val grid = GridLayout(this).apply {
            columnCount = 3
            useDefaultMargins = true
        }
        val keys = listOf("Power", "Mute", "Source", "Volume +", "Volume −",
            "Channel +", "Channel −", "Up", "Down", "Left", "OK", "Right", "Menu", "Back")
        keys.forEach { key ->
            val button = Button(this).apply {
                text = key
                isAllCaps = false
                setOnClickListener { sendKey(key) }
            }
            grid.addView(button, ViewGroup.LayoutParams(0, 125).apply {
                width = resources.displayMetrics.widthPixels / 3 - 34
            })
        }
        page.addView(grid)
        page.addView(label("Note: brand selection does not automatically guarantee a matching code. These starter profiles are generic test signals; Walton/model-specific IR codes still need to be added and verified.", 12f))
        val scroll = ScrollView(this)
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun updateStatus() {
        val supported = ir.hasIrEmitter()
        val freqs = if (supported) runCatching { ir.carrierFrequencies }.getOrNull() else null
        status.text = if (!supported) {
            "IR emitter not detected by Android. This phone may not expose its IR hardware to apps."
        } else {
            "IR emitter detected. Carrier ranges: " +
                (freqs?.joinToString { "${it.minFrequency}-${it.maxFrequency} Hz" } ?: "not reported")
        }
    }

    private fun sendKey(key: String) {
        if (!ir.hasIrEmitter()) {
            toast("Android cannot detect an IR emitter on this phone.")
            return
        }
        val cmd = commands[key]
        if (cmd == null) {
            toast("No command mapping for this key.")
            return
        }
        val addr = profiles[profile.selectedItemPosition].address
        val pattern = necPattern(addr, cmd)
        try {
            ir.transmit(38000, pattern)
            toast("$key IR signal sent • ${brand.selectedItem}")
        } catch (e: Exception) {
            toast("IR send failed: ${e.message ?: "unknown error"}")
        }
    }

    private fun necPattern(address: Int, command: Int): IntArray {
        val bytes = intArrayOf(address and 0xFF, (address.inv()) and 0xFF,
            command and 0xFF, (command.inv()) and 0xFF)
        val out = ArrayList<Int>()
        out.add(9000); out.add(4500)
        for (b in bytes) {
            for (i in 0..7) {
                out.add(560)
                out.add(if (((b shr i) and 1) == 1) 1690 else 560)
            }
        }
        out.add(560)
        return out.toIntArray()
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
